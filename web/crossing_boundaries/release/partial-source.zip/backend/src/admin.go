package app

import (
	"log"
	"net/http"
	"time"

	"github.com/google/uuid"
)

func (a *App) adminFlag(w http.ResponseWriter, r *http.Request) {
	s := a.getSession(r)
	if s == nil || s.Username != adminUsername {
		http.Error(w, "You are not admin. Are you?", 401)
		return
	}

	w.Write([]byte(a.Config.Flag))
}

func (a *App) triggerAdminReview(blogID string) {
	time.Sleep(10 * time.Second)

	req, _ := http.NewRequest(
		"GET",
		a.Config.UpstreamAddr+"/blogs/"+blogID,
		nil,
	)

	req.AddCookie(&http.Cookie{
		Name:  "session",
		Value: a.Config.AdminSessionID, // UUID
	})
	req.Host = a.Config.HostName
	req.Header.Set("User-Agent", "AdminBot/1.0")

	resp, err := a.Client.Do(req)
	if err == nil {
		defer resp.Body.Close()
		_, err = a.DB.Exec(
			"INSERT INTO reviews VALUES (?, ?, ?, ?)",
			uuid.New().String(),
			blogID,
			"Good blog!",
			time.Now().UnixMilli(),
		)
	}

	if err != nil {
		log.Printf("Admin review failed for %s: %v", blogID, err)
		return
	}

	log.Printf("Admin review %s -> %s", blogID, resp.Status)
}
